// Write your WordGuesser class headers here.

// The code already in this file is a print operator implementation
// to help you test your code. You do not have to use it.

#include <set>

// print operator for a set of any type
// outputs all items in the set separated by spaces
template <typename T>
ostream& operator<< (ostream& out, const set<T>& words) {
    for(const T& word : words) {
        cout << (T)word << " "; 
    }
    return out;
}

